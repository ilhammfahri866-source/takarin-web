# Takarin — Presisi Takaran Matcha & Teh Artisanal (Multi-Page Architecture)

Aplikasi web pemesanan matcha & teh artisanal berbasis presisi takaran angka (0%–100%) dengan arsitektur multi-page terpisah yang bersih, modern, dan dapat langsung dijalankan secara offline di browser (cukup klik ganda `index.html`).

---

## 📂 Struktur Halaman & File

```text
c:\takarin\
├── index.html        # Halaman 01: Beranda (Refined Navbar, Hero Showcase Dual-Cup, SCAMPER Matrix, Menu Unggulan)
├── katalog.html      # Halaman 02: Katalog Menu Terkalibrasi (Banner Reverse Takaran Awal, Filter Kategori & Quick Order)
├── racik.html        # Halaman 03: Racik Presisi (Simulator Gelas SVG Interaktif, Slider 0%-100%, Toggle Es Dipisah, Form Simpan MyMix)
├── mymix.html        # Halaman 04: MyMix Presets & Layar Barista Kitchen Display System (KDS) dengan Cetak 2-Label
├── pesanan.html      # Halaman 05: Keranjang Belanja, Checkout Instan, Riwayat Pesanan & Garansi Rasa/Porsi
├── css/
│   └── style.css     # Master Stylesheet (CSS variables, paper texture, custom precision sliders, anim)
└── js/
    ├── data.js       # Master katalog menu matcha/teh, formula ml sirup & gramasi es terkalibrasi
    └── state.js      # Shared state engine (LocalStorage, Cart, Presets, Orders, Vouchers, Toast)
```

---

## 🎨 Pembaruan Desain & Navbar

1. **Refined Navigation Bar (`h-20` / Sticky Header)**:
   - Cap logo artisanal Jepang beraksara `茶` (Teh) dengan wordmark `TAKARIN LAB`.
   - Navigasi multi-halaman yang konsisten di semua halaman (`index.html`, `katalog.html`, `racik.html`, `mymix.html`, `pesanan.html`).
   - Indikator profil takaran aktif langsung di header (*Gula 30% • Es 20%*).
   - Tombol keranjang dengan badge jumlah gelas yang tersinkronisasi secara real-time.

2. **Hero Section Beranda yang Menarik & Interaktif**:
   - Headline editorial berwibawa khas Kyoto artisanal tea lab.
   - Pilihan quick-preset tag langsung di Hero: *Diet Low-Cal*, *Pure Ceremonial*, *Pas McQueen*, *Sweet Weekend*.
   - **Simulator Dual-Cup SVG Interaktif**:
     - Menampilkan visual cairan pekat teh & sirup gula pada Cup 1.
     - Menampilkan kristal es batu pada Cup 2 saat opsi **Es Dipisah** dipilih.
     - Slider live preview yang langsung terkalibrasi dengan gramasi es dan mililiter sirup.

3. **Konsistensi Desain Tanpa "AI Slop"**:
   - Tipografi seimbang: **Newsreader** (serif editorial bergaya Kyoto) dan **Plus Jakarta Sans** (sans-serif bersih & modern).
   - Palet warna artisanal: *Matcha Green* (`#3A5A40`), *Paper White* (`#FBFBF9`), *Stone Gray* (`#F3F2EE`), *Charcoal* (`#1C1D1B`), dan *Amber Syrup* (`#D4A373`).

---

## 🚀 Fitur Inti (Kerangka Inovasi SCAMPER — LKPD 5)

1. **Substitute & Eliminate (Slider Takaran Angka 0%–100%)**
   - Menghilangkan label ambigu *"Normal / Sedang / Less"*.
   - Slider persentase presisi (kelipatan 5% atau 10%) dilengkapi konversi pasti mililiter sirup dan gramasi es batu kristal.

2. **Combine (Paket Es Dipisah Tanpa Biaya Tambahan)**
   - Minuman utama dikemas 100% murni tanpa es batu agar konsentrasi matcha tidak encer selama perjalanan kurir.
   - Es batu dikemas pada cup kedua terpisah, otomatis mencetak instruksi **2 Label Stiker** di layar barista (KDS).

3. **Adapt (MyMix Preset 1-Klik)**
   - Simpan kombinasi takaran favorit pembeli ke `localStorage`.
   - Panggil kembali atau pesan langsung dalam 1 klik dari katalog menu atau halaman MyMix.

4. **Put to Another Use (Garansi Rasa & Porsi Otomatis)**
   - Data spesifikasi takaran digital berfungsi sebagai bukti transaksi sah.
   - Jika minuman diterima tidak sesuai (misal terlalu manis atau es mencair), pembeli dapat mengajukan klaim untuk mendapatkan voucher kompensasi Rp 15.000 secara otomatis.

---

## 🖥️ Cara Menjalankan

1. Buka folder `c:\takarin` di File Explorer.
2. Klik ganda `index.html` untuk membuka aplikasi di browser favorit Anda (Google Chrome, Microsoft Edge, Mozilla Firefox, dll.).
3. Semua halaman dan fitur bekerja 100% tanpa perlu server lokal atau koneksi internet khusus.
