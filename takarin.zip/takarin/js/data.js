// Takarin - Master Menu Data & Helpers (Shared Across All Pages)

const MENU_ITEMS = [
  {
    id: 'uji-ceremonial-latte',
    name: 'Uji Ceremonial Matcha Latte',
    category: 'Matcha Latte & Fusion',
    origin: 'Uji, Kyoto • Kultivar Asahi',
    baseLiquidMl: 210,
    maxSyrupMl: 30,
    maxIceGram: 150,
    liquidColor: '#3A5A40',
    price: 38000,
    description: 'Tencha panen pertama gilingan batu granit dikocok segar dengan susu murni dingin. Rasio teh tinggi sehingga karakter umami tetap tegas meski ditambah es.',
    image: 'https://images.unsplash.com/photo-1515823064-d6e0c04616a7?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'pure-usucha-cold',
    name: 'Pure Uji Usucha (Tanpa Susu)',
    category: 'Ceremonial & Signature Matcha',
    origin: 'Uji, Kyoto • Single Cultivar',
    baseLiquidMl: 180,
    maxSyrupMl: 25,
    maxIceGram: 140,
    liquidColor: '#2E5233',
    price: 36000,
    description: 'Seduhan murni 3 gram ceremonial matcha dengan air mineral terkalibrasi. Jernih, menyegarkan, dan menonjolkan manis alami daun tencha.',
    image: 'https://images.unsplash.com/photo-1582793988951-9aed5509eb97?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'okumidori-cloud-matcha',
    name: 'Okumidori Oat Matcha',
    category: 'Matcha Latte & Fusion',
    origin: 'Yame, Fukuoka',
    baseLiquidMl: 220,
    maxSyrupMl: 30,
    maxIceGram: 150,
    liquidColor: '#486B4E',
    price: 42000,
    description: 'Kultivar Okumidori berkarakter kacang panggang lembut dipadukan susu oat barista yang tidak menutupi aroma daun teh.',
    image: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'yuzu-ceremonial-fizz',
    name: 'Yuzu Ceremonial Matcha Tonic',
    category: 'Ceremonial & Signature Matcha',
    origin: 'Wazuka & Kochi',
    baseLiquidMl: 200,
    maxSyrupMl: 30,
    maxIceGram: 150,
    liquidColor: '#4F7748',
    price: 40000,
    description: 'Lapisan konsentrat matcha Wazuka di atas sari jeruk yuzu Jepang dan air soda dingin. Sangat disarankan menggunakan opsi Es Dipisah.',
    image: 'https://images.unsplash.com/photo-1563822249366-3efb23b8e0c9?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'kaga-hojicha-latte',
    name: 'Kaga-Boucha Hojicha Latte',
    category: 'Hojicha & Teh Sangrai',
    origin: 'Ishikawa • Stem-Roasted',
    baseLiquidMl: 210,
    maxSyrupMl: 30,
    maxIceGram: 150,
    liquidColor: '#6E5038',
    price: 35000,
    description: 'Tangkai teh hijau yang disangrai pada suhu tinggi hingga menghasilkan aroma karamel panggang dan cokelat hangat dengan kafein rendah.',
    image: 'https://images.unsplash.com/photo-1597318181409-cf64d0b5d8a2?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'genmaicha-cream-latte',
    name: 'Uji Genmaicha Roasted Latte',
    category: 'Hojicha & Teh Sangrai',
    origin: 'Kyoto • Sencha & Beras Sangrai',
    baseLiquidMl: 210,
    maxSyrupMl: 30,
    maxIceGram: 150,
    liquidColor: '#7A6844',
    price: 36000,
    description: 'Seduhan pekat sencha dan beras ketan panggang Jepang berpadu susu segar. Gurih, menenangkan, dan pas di takaran gula rendah.',
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'kuromitsu-kinako-milk',
    name: 'Kuromitsu Kinako Soy Milk',
    category: 'Non-Matcha & Add-ons',
    origin: 'Okinawa & Kyoto',
    baseLiquidMl: 210,
    maxSyrupMl: 35,
    maxIceGram: 150,
    liquidColor: '#9C8265',
    price: 32000,
    description: 'Susu kedelai artisanal dengan bubuk kedelai panggang kinako dan sirup gula tebu hitam Okinawa yang bisa diatur dari 0% hingga 100%.',
    image: 'https://images.unsplash.com/photo-1545048702-79362596cdc9?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'extra-whisked-shot',
    name: 'Double Whisked Matcha Shot (+2g)',
    category: 'Non-Matcha & Add-ons',
    origin: 'Uji, Kyoto',
    baseLiquidMl: 60,
    maxSyrupMl: 15,
    maxIceGram: 60,
    liquidColor: '#29462E',
    price: 18000,
    description: 'Tambahan 2 gram konsentrat matcha gilingan batu yang dikocok terpisah bagi penikmat karakter teh ekstra pekat.',
    image: 'https://images.unsplash.com/photo-1564890369478-c89ca6d9cde9?auto=format&fit=crop&w=800&q=80'
  }
];

function formatRupiah(num) {
  return 'Rp ' + Math.round(num).toLocaleString('id-ID');
}

function computeMetrics(drink, sugarPct, icePct) {
  const sugarMl = Math.round((sugarPct / 100) * drink.maxSyrupMl);
  const iceGram = Math.round((icePct / 100) * drink.maxIceGram);
  const iceVolMl = Math.round(iceGram * 0.9);
  const totalCombinedMl = drink.baseLiquidMl + sugarMl + iceVolMl;
  const pureDrinkMl = drink.baseLiquidMl + sugarMl;

  return {
    sugarMl,
    iceGram,
    iceVolMl,
    pureDrinkMl,
    totalCombinedMl
  };
}
