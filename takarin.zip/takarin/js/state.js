// Takarin - Shared Application State Engine & LocalStorage Manager

const STORAGE_KEYS = {
  PROFILE: 'takarin_global_profile_v1',
  PRESETS: 'takarin_mymix_presets_v1',
  CART: 'takarin_cart_v1',
  ORDERS: 'takarin_orders_v1',
  VOUCHERS: 'takarin_vouchers_v1'
};

const DEFAULT_PRESETS = [
  {
    id: 'preset-mcqueen-1',
    presetName: 'Resep Pas McQueen',
    drinkId: 'uji-ceremonial-latte',
    sugarPct: 30,
    icePct: 20,
    separateIce: true,
    notes: 'Standar harian McQueen: manis tipis, es dipisah agar tidak encer di perjalanan.'
  }
];

const DEFAULT_ORDERS = [
  {
    id: 'TKR-2084',
    createdAt: 'Hari ini, 08:15 WIB',
    customerName: 'McQueen',
    fulfillment: 'Ambil di Ruang Seduh (Takeaway)',
    orderNote: 'Pastikan label cup es ditempel terpisah.',
    status: 'Selesai Diseduh',
    total: 38000,
    discount: 0,
    claimed: false,
    claimReason: '',
    items: [
      {
        drinkId: 'uji-ceremonial-latte',
        name: 'Uji Ceremonial Matcha Latte',
        price: 38000,
        qty: 1,
        sugarPct: 30,
        sugarMl: 9,
        icePct: 20,
        iceGram: 30,
        baseLiquidMl: 210,
        separateIce: true
      }
    ]
  }
];

const TakarinState = {
  getProfile() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return data ? JSON.parse(data) : { sugarPct: 30, icePct: 20, separateIce: true };
    } catch (e) {
      return { sugarPct: 30, icePct: 20, separateIce: true };
    }
  },

  setProfile(profile) {
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
    this.updateBadges();
  },

  getPresets() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PRESETS);
      return data ? JSON.parse(data) : [...DEFAULT_PRESETS];
    } catch (e) {
      return [...DEFAULT_PRESETS];
    }
  },

  savePresets(presets) {
    localStorage.setItem(STORAGE_KEYS.PRESETS, JSON.stringify(presets));
    this.updateBadges();
  },

  getCart() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CART);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  },

  saveCart(cart) {
    localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
    this.updateBadges();
  },

  addToCart(item) {
    const cart = this.getCart();
    const existingIdx = cart.findIndex(i =>
      i.drinkId === item.drinkId &&
      i.sugarPct === item.sugarPct &&
      i.icePct === item.icePct &&
      i.separateIce === item.separateIce
    );

    if (existingIdx >= 0) {
      cart[existingIdx].qty += item.qty;
    } else {
      cart.push(item);
    }
    this.saveCart(cart);
  },

  getOrders() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ORDERS);
      return data ? JSON.parse(data) : [...DEFAULT_ORDERS];
    } catch (e) {
      return [...DEFAULT_ORDERS];
    }
  },

  saveOrders(orders) {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  },

  getVouchers() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.VOUCHERS);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  },

  saveVouchers(vouchers) {
    localStorage.setItem(STORAGE_KEYS.VOUCHERS, JSON.stringify(vouchers));
  },

  updateBadges() {
    const cart = this.getCart();
    const presets = this.getPresets();
    const profile = this.getProfile();

    const cartQty = cart.reduce((acc, item) => acc + item.qty, 0);

    const navCart = document.getElementById('nav-cart-count');
    const mobileHeaderCart = document.getElementById('mobile-header-cart-badge');
    const mobileDot = document.getElementById('mobile-tab-cart-dot');
    const navPreset = document.getElementById('nav-preset-count');
    const headerSummary = document.getElementById('header-profile-summary');

    if (navCart) navCart.textContent = cartQty;
    if (mobileHeaderCart) mobileHeaderCart.textContent = cartQty;
    if (mobileDot) mobileDot.classList.toggle('hidden', cartQty === 0);
    if (navPreset) navPreset.textContent = presets.length;
    if (headerSummary) {
      headerSummary.textContent = `Gula ${profile.sugarPct}% • Es ${profile.icePct}%`;
    }
  }
};

// Global Toast
let toastTimer;
function showToast(msg) {
  const el = document.getElementById('toast');
  const msgEl = document.getElementById('toast-message');
  if (!el || !msgEl) return;
  msgEl.textContent = msg;
  el.classList.remove('translate-y-24', 'opacity-0');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    el.classList.add('translate-y-24', 'opacity-0');
  }, 2600);
}

// Order preset in 1-click from any page
function orderPresetOneClick(presetId) {
  const presets = TakarinState.getPresets();
  const preset = presets.find(p => p.id === presetId);
  if (!preset) return;
  const drink = MENU_ITEMS.find(d => d.id === preset.drinkId) || MENU_ITEMS[0];
  const metrics = computeMetrics(drink, preset.sugarPct, preset.icePct);

  TakarinState.addToCart({
    drinkId: drink.id,
    name: drink.name,
    price: drink.price,
    qty: 1,
    sugarPct: preset.sugarPct,
    sugarMl: metrics.sugarMl,
    icePct: preset.icePct,
    iceGram: metrics.iceGram,
    baseLiquidMl: drink.baseLiquidMl,
    separateIce: preset.separateIce
  });

  showToast(`1-Klik "${preset.presetName}" ditambahkan ke keranjang`);
}

document.addEventListener('DOMContentLoaded', () => {
  TakarinState.updateBadges();
});
